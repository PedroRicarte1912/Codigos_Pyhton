from api.model.Professores import Professores
from api.model.Disciplinas import Disciplinas

class ProfessoresDAO:
    def __init__(self,database_dependency):
        print("⬆️  ProfessoresDAO.__init__()")
        self.__database = database_dependency
    
    #Cria um professor em Professores table
    def criar(self,objProf:Professores)->int:
        print("🟢 ProfessoresDAO.criar()")
        SQL="""insert into Professores (id,nome,email,id_disc) values (%s,%s,%s,%s);"""
        params=(
            objProf.Idprofessores,
            objProf.Nomeprofessores,
            objProf.Emailprofessores,
            objProf.disciplinas,
        )
        with self.__database.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(SQL,params)
                cursor.commit()
                insert_id=cursor.lastrowid
        if not insert_id:
            raise Exception("Falha ao inserir professor")
        return insert_id
    
    #Deleta professor de Professores table
    def deleta(self,IdProf:int)->bool:
        print("🟢 ProfessoresDAO.deleta()")
        SQL="delete from Professores where id=%s;"
        with self.__database.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(SQL,(IdProf))
                conn.commit()
                afetados=cursor.rowcount
        return afetados>0
    
    #Atualiza professor de Professores
    def atualiza(self,objProf:Professores,idProf:int)->bool:
        print("🟢 ProfessoresDAO.atualiza()")
        if idProf==objProf.Idprofessores:
            SQL="""update Professores set nome=%s,email=%s,id_disc=%s where id=%s;"""
            params=(
                objProf.Nomeprofessores,
                objProf.Emailprofessores,
                objProf.disciplinas,
                idProf,
            )
        else:
            raise ValueError(f"O id {idProf} não existe ainda ")
        with self.__database.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(SQL,params)
                conn.commit()
                afetados=cursor.rowcount
        return afetados>0
    
    #Acha todos os professores em Professores
    def findAll(self)->list[dict]:
        print("🟢 ProfessoresDAO.findAll()")
        SQL="""select id, nome, email, id_disc from Professores join Disciplinas on Professores.id_disc=id_disciplina;"""
        with self.__database.get_connection() as conn:
            with conn.cursor(dictionary=True) as cursor:
                cursor.execute(SQL)
                rows=cursor.fetchall()
        professores=[
            {
                "Id professor": row["id"],
                "nome professor":row["nome"],
                "email":row["email"],
                "disciplina":{
                    "id disciplina":row["id_disciplina"],
                    "nome disciplina":row["nome_disciplina"]
                }
            }
            for row in rows
        ]
        return professores
    
    #acha por id em Professores
    def findById(self,idProf:int)->dict|None:
        professoresRaw=self.findByField("id",idProf)
        print("✅ ProfessoresDAO.findById()")
        return professoresRaw[0] if professoresRaw else None
    
    #Acha por coluna em Professores
    def findByField(self,campo:str,valor)->list[dict]:
        print(f"🟢 ProfessoresDAO.findByField() - Campo: {campo}, Valor: {valor}")
        campos_permitidos=["id","nome","email","id_disc"]
        if campo not in campos_permitidos:
            raise ValueError(f"Campo {campo} não permitido")
        SQL=f"select * from  Professores where {campo}=%s;"
        with self.__database.get_connection() as conn:
            with conn.cursor(dictionary=True) as cursor:
                cursor.execute(SQL,(valor))
                resultados=cursor.fetchall()
        return resultados
    
    # Login do professor
    def login(self,objProf:Professores)->Professores|None:
        print("🟢 ProfessoresDAO.login()")
        SQL="""select id, nome, email, id, nome from Professores join Disciplinas on Disciplinas.id_disciplina=Professores.id_disc where email=%s;"""
        with self.__database.get_connection() as conn:
            with conn.cursor(dictionary=True) as cursor:
                cursor.execute(SQL,(objProf.Emailprofessores))
                rows=cursor.fetchall()
        if len(rows)!=1:
            print("Funcionário não encontrado")
            return None

        professoresDB=rows[0]

        objDisc=Disciplinas()
        objDisc.Iddisciplinas=int(professoresDB["id_disciplina"])
        objDisc.Nomedisciplinas=professoresDB["nome_disciplina"]

        professor=Professores()
        professor.Idprofessores=professoresDB["id"]
        professor.Nomeprofessores=professoresDB["nome"]
        professor.Emailprofessores=professoresDB["email"]
        professor.disciplinas=objDisc

        print("✅ ProfessoresDAO.login() -> sucesso")
        return professor