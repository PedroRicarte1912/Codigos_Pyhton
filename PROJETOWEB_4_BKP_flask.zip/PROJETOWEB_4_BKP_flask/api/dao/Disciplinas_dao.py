from api.model.Disciplinas import Disciplinas

class DisciplinasDAO:
    def __init__(self,database_dependency):
        print("⬆️  DisciplinasDAO.__init__()")
        self.__database = database_dependency

    #Criação de disciplina nova
    def create(self,objDisc:Disciplinas)->int:
        SQL="insert into Disciplinas (id_disciplina,nome) values (%s,%s); "
        params=(objDisc.Iddisciplinas,objDisc.Nomedisciplinas)

        with self.__database.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(SQL,params)
                conn.commit()
        print("✅ CargoDAO.create()") 
        return objDisc.Iddisciplinas
    
    #Deleta disciplina existente
    def delete(self, disciplina:Disciplinas)->bool:
        SQL="delete from Disciplinas where id_disciplina=%s;"
        params=(disciplina.Iddisciplinas)

        with self.__database.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(SQL,params)
                conn.commit()
                affected=cursor.rowcount
        print("✅ CargoDAO.delete()")
        return affected>0
    
    #Atualiza disciplina existente
    def update(self,objDisc:Disciplinas)->bool:
        SQL="update Disciplinas set nome=%s where id_disciplina=%s;"
        params=(objDisc.Nomedisciplinas,objDisc.Iddisciplinas)
        with self.__database.get.connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(SQL,params)
                conn.commit()
                afetados=cursor.rowcount
        print("✅ DisciplinasDAO.update()")
        return afetados > 0
    
    #acha tudo em Disciplinas table
    def findAll(self)-> list[dict]:
        SQL="select*from Disciplinas;"
        with self.__database.get_connection() as conn:
            with conn.cursor(dictionary=True) as cursor:
                cursor.execute(SQL)
                resultados=cursor.fetchall()
        print(f"✅ DisciplinasDAO.findAll() -> {len(resultados)} registros encontrados")
        return resultados
    
    #acha por ID da disciplina
    def findById(self,IdDisc:int)->dict|None:
        resultados=self.findByField("id_disciplina",IdDisc)
        print("✅ DisciplinasDAO.findById()")
        return resultados[0] if resultados else None
    
    #acha por coluna de Disciplinas
    def findByField(self,field:str,value)->list[dict]:
        campos_permitidos=["id_disciplina","nome_disciplina"]
        if field not in campos_permitidos:
            raise ValueError(f"Campo inválido para busca:{field}")
        SQL="select*from Disciplinas where {field}=%s;"
        params=(value)
        with self.__database.get_connection() as conn:
            with conn.cursor(dictionary=True) as cursor:
                cursor.execute(SQL,params)
                resultados=cursor.fetchall()
        print("✅ DisciplinasDAO.findByField()")
        return resultados
        