from api.model.DisciplinasXProfessores import DisciplinasXProfessores   

class DisciplinasXProfessoresDAO:
    def __init__(self, database_dependency):
        print("⬆️  DisciplinasXProfessoresDAO.__init__()")
        self.__database = database_dependency

        def create(self, objDxP: DisciplinasXProfessores) -> str:
            SQL = """INSERT INTO DisciplinasXProfessores 
                     (codigodisciplinanocurso, 
                     coddisciplina, 
                     codprofessor, 
                     curso, 
                     cargahoraria,
                     anoletivo) 
                     VALUES (%s, %s, %s, %s, %s, %s);"""
            params = (
                objDxP.CodigoDisciplinaNoCurso,
                objDxP.CodDisciplina,
                objDxP.CodProfessor,
                objDxP.Curso,
                objDxP.CargaHoraria,
                objDxP.AnoLetivo
            )

            with self.__database.get_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(SQL, params)
                    conn.commit()
            print("✅ DisciplinasXProfessoresDAO.create()")
            return objDxP.CodigoDisciplinaNoCurso
        
        def update(self, objRel: DisciplinasXProfessores) -> bool:
            SQL = """
                UPDATE disciplinasxprofessores
                SET coddisciplina = %s,
                    codprofessor = %s,
                    curso = %s,
                    cargahoraria = %s,
                    anoletivo = %s
                WHERE codigodisciplinanocurso = %s;
            """
            params = (
                objRel.CodDisciplina,
                objRel.CodProfessor,
                objRel.Curso,
                objRel.CargaHoraria,
                objRel.AnoLetivo,
                objRel.CodigoDisciplinaNoCurso
            )

            with self.__database.get_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(SQL, params)
                    conn.commit()
                    afetados = cursor.rowcount
            print("✅ DisciplinasXProfessoresDAO.update()")
            return afetados > 0
        
        def findAll(self) -> list[dict]:
            SQL = "SELECT * FROM disciplinasxprofessores;"
            with self.__database.get_connection() as conn:
                with conn.cursor(dictionary=True) as cursor:
                    cursor.execute(SQL)
                    resultados = cursor.fetchall()
            print(f"✅ DisciplinasXProfessoresDAO.findAll() -> {len(resultados)} registros encontrados")
            return resultados
        def findByField(self, field: str, value) -> list[dict]:
            campos_permitidos = [
                "codigodisciplinanocurso",
                "coddisciplina",
                "codprofessor",
                "curso",
                "cargahoraria",
                "anoletivo"
            ]
            if field not in campos_permitidos:
                raise ValueError(f"Campo inválido para busca: {field}")

            SQL = f"SELECT * FROM disciplinasxprofessores WHERE {field} = %s;"
            params = (value,)

            with self.__database.get_connection() as conn:
                with conn.cursor(dictionary=True) as cursor:
                    cursor.execute(SQL, params)
                    resultados = cursor.fetchall()
            print("✅ DisciplinasXProfessoresDAO.findByField()")
            return resultados

