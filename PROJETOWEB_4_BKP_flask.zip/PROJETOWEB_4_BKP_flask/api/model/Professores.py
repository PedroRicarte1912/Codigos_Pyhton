from api.model.Disciplinas import disciplinas


class Professores:
    def __init__(self):
        self.__Idprofessores=None
        self.__Nomeprofessores=None
        self.__Emailprofessores=None
        self.__disciplinas=disciplinas.__Iddisciplinas
    @property
    def Idprofessores(self):
        return self.__Idprofessores
    @Idprofessores.setter
    def Idprofessores(self,value):
        try:
            parsed = int(value)
        except (ValueError,TypeError):
            raise ValueError("Idprofessores deve ser um número inteiro")
        if parsed<=0:
            raise ValueError("Idprofessores deve ser maior de 0")
        self.__Idprofessores=parsed

    @property
    def Nomeprofessores(self):
        return self.__Nomeprofessores
    @Nomeprofessores.setter
    def Nomeprofessores(self,value):
        if not isinstance(value,str):
            raise ValueError("Nome do professor deve ser uma string")
        nome = value.strip()
        if len(nome)<3:
            raise ValueError("Nome do professro deve ter pelo menos 3 caracteres")
        self.__Nomeprofessores=nome

    @property
    def Emailprofessores(self):
        return self.__Emailprofessores
    @Emailprofessores.setter
    def Emailprofessores(self,value):
        if not isinstance(value,str):
            raise ValueError("Email do professro deve ser uma string")
        email=value.strip()
        self.__Emailprofessores=email
    
    @property
    def disciplinas(self):
        return self.__disciplinas