# -*- coding: utf-8 -*-
"""
Representa a entidade disciplinasXprofessores do sistema.

==> Objetivo:
- Encapsular os dados de uma relação entre disciplina e professor.
- Garantir integridade dos atributos via getters e setters.
"""

class DisciplinasXProfessores:
    def __init__(self):
        """
        Inicializa todos os atributos como atributos de instância.
        """
        self.__CodigoDisciplinaNoCurso = None
        self.__CodDisciplina = None
        self.__CodProfessor = None
        self.__Curso = None
        self.__CargaHoraria = None
        self.__AnoLetivo = None

    @property
    def CodigoDisciplinaNoCurso(self):
        return self.__CodigoDisciplinaNoCurso

    @CodigoDisciplinaNoCurso.setter
    def CodigoDisciplinaNoCurso(self, value):
        if not isinstance(value, str):
            raise ValueError("CodigoDisciplinaNoCurso deve ser uma string.")
        codigo = value.strip()
        if len(codigo) == 0:
            raise ValueError("CodigoDisciplinaNoCurso não pode ser vazio.")
        if len(codigo) > 10:
            raise ValueError("CodigoDisciplinaNoCurso deve ter no máximo 10 caracteres.")
        self.__CodigoDisciplinaNoCurso = codigo



    @property
    def CodDisciplina(self):
        return self.__CodDisciplina

    @CodDisciplina.setter
    def CodDisciplina(self, value):
        try:
            parsed = int(value)
        except (ValueError, TypeError):
            raise ValueError("CodDisciplina deve ser um número inteiro.")
        if parsed <= 0:
            raise ValueError("CodDisciplina deve ser maior que zero.")
        self.__CodDisciplina = parsed

   

    @property
    def CodProfessor(self):
        return self.__CodProfessor

    @CodProfessor.setter
    def CodProfessor(self, value):
        try:
            parsed = int(value)
        except (ValueError, TypeError):
            raise ValueError("CodProfessor deve ser um número inteiro.")
        if parsed <= 0:
            raise ValueError("CodProfessor deve ser maior que zero.")
        self.__CodProfessor = parsed

 

    @property
    def Curso(self):
        return self.__Curso

    @Curso.setter
    def Curso(self, value):
        try:
            parsed = int(value)
        except (ValueError, TypeError):
            raise ValueError("Curso deve ser um número inteiro.")
        if parsed <= 0:
            raise ValueError("Curso deve ser maior que zero.")
        self.__Curso = parsed



    @property
    def CargaHoraria(self):
        return self.__CargaHoraria

    @CargaHoraria.setter
    def CargaHoraria(self, value):
        try:
            parsed = int(value)
        except (ValueError, TypeError):
            raise ValueError("CargaHoraria deve ser um número inteiro.")
        if parsed <= 0:
            raise ValueError("CargaHoraria deve ser maior que zero.")
        self.__CargaHoraria = parsed



    @property
    def AnoLetivo(self):
        return self.__AnoLetivo

    @AnoLetivo.setter
    def AnoLetivo(self, value):
        try:
            parsed = int(value)
        except (ValueError, TypeError):
            raise ValueError("AnoLetivo deve ser um número inteiro.")
        if parsed < 2000:
            raise ValueError("AnoLetivo deve ser igual ou superior a 2000.")
        self.__AnoLetivo = parsed

