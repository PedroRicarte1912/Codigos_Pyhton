# -*- coding: utf-8 -*-
"""
Representa a entidade disciplinas do sistema.

==>Objetivo:
- Encapsular os dados de uma disciplina.
- Garantir integridade dos atributos via getters e setters.
"""
class Disciplinas :
    def __init__(self):
        """
        Inicializa todos os atributos como atributos de instância.
        """
        self.__Iddisciplinas=None
        self.__Nomedisciplina=None

    @property
    def Iddisciplinas(self):
            return self.__Iddisciplinas
        
    @Iddisciplinas.setter
    def Iddisciplinas(self,value):
            try:
                parsed = int(value)
            except (ValueError, TypeError):
                raise ValueError("iddisciplinas deve ser um número inteiro.")

            if parsed <= 0:
                raise ValueError("idsiciplinas deve ser maior que zero.")
            self.__iddisciplinas = parsed

    @property
    def Nomedisciplinas(self):
            return self.__Nomedisciplinas
        
    @Nomedisciplinas.setter
    def Nomedisciplinas(self,value):
        if not isinstance(value, str):
            raise ValueError("nome disciplinas  deve ser uma string.")

        nome = value.strip()
        if len(nome) < 3:
            raise ValueError("nome disciplinas deve ter pelo menos 3 caracteres.")
        self.__Nomedisciplinas = nome