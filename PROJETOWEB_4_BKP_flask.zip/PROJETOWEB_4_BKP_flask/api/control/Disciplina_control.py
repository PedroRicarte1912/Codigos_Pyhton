from flask import request, jsonify
from api.service.Disciplina_service import DisciplinaService

class DisciplinaControl:
    def __Init__(self,disc_service:DisciplinaService):
        print("⬆️  DisciplinaControl.constructor()")
        self.__disc_service = disc_service
    
    def store(self):
        print("🔵 DisciplinaControl.store()")
        disciplina_body_request = request.json.get("disciplina")
        novo_id = self.__disc_service.CriaDisc(disciplina_body_request)
        obj_resposta={
            "sucess":True,
            "Message":"Cadastro realizado com sucesso",
            "data":{
                "disciplinas":[
                    {
                        "Id_disciplina":novo_id,
                        "nome_disciplina":disciplina_body_request("nome_disciplina")
                    }
                ]
            }
        }
        if novo_id:
            return jsonify(obj_resposta),200
        
    def index(self):
        print("🔵 DisciplinaControl.index()")
        array_disciplinas=self.__disc_service.findAll()
        return jsonify({
            "sucess":True,
            "Message":"Busca realizada com sucesso",
            "data":{"Disciplinas":array_disciplinas}
        }),200
    
    def show(self):
        id_disciplina=request.view_args.get("id_disciplinas")
        disciplina=self.__disc_service.findById(id_disciplina)
        obj_resposta={
            "sucess":True,
            "Message":"Executado com sucesso",
            "data":{"diciplina":disciplina}
        }
        return jsonify(obj_resposta),200
    
    def update(self):
        print("🔵 DisciplinaControl.update()")
        id_disciplina=request.view_args.get("id_disciplina")
        json_disc=request.json.get("disciplina")
        print(json_disc)
        reposta=self.__disc_service.atualiza(id_disciplina,json_disc)
        return jsonify({
            "success": True,
            "message": "disciplina atualizada com sucesso",
            "data": {
                "disciplina": {
                    "id_disciplina": int(id_disciplina),
                    "nomeCargo": json_disc.get("nome_disciplina")
                }
            }
        }), 200
    
    def destroy(self):
          print("🔵 DisciplinaControl.destroy()")
          id_disciplina=request.view_args.get("id_disciplina")
          excluiu=self.__disc_service.deleta(id_disciplina)
          if not excluiu:
              return jsonify({
                  "sucess":False,
                  "Message":f"Não existe disciplina com esse id {id_disciplina}"
              }),400
          return jsonify({
              "sucess":True,
              "Message":"Excluído com sucesso"
          }),204