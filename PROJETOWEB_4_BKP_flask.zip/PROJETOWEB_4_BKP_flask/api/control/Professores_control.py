from flask import request, jsonify
import traceback
from api.service.Professores_service import ProfessoresService

class ProfessoresControl:
    def __init__(self,profe_service:ProfessoresService):
        print("⬆️  ProfessoresControl.constructor()")
        self.__profe_service=profe_service
    
    def login(self):
         print ("🔵 ProfessoresControl.login()")
         json_prof=request.json.get("professor")
         resultado=self.__profe_service.login(json_prof)
         return jsonify({
             "sucess":True,
             "Message":"Login efetuado com sucesso",
             "data":resultado
         }),201
    
    def store(self):
           print("🔵 ProfessoresControl.store()")
           json_profe=request.json.get("professor")
           newIdProfe=self.__profe_service.cria(json_profe)
           return jsonify({
                "sucess":True,
                "Message":"Cadastro realizado com sucesso",
                "data":{
                     "professor":{
                          "idProfessor":newIdProfe,
                          "nomeProfessor":json_profe.get("nome"),
                          "email":json_profe.get("email"),
                          "disciplina":{
                               "idDisciplina":json_profe.get("disciplina",{}).get("id_disciplina"),
                               "nomeDisc":json_profe.get("disciplina",{}).get("nome_disciplina")
                          }
                     }
                }
           }),201
    
    def index(self):
         lista_prof=self.__profe_service.findAll()
         return jsonify({
              "sucess":True,
              "message":"Executado com sucesso",
              "data":{"Professores":lista_prof}
         }),200
    
    def show(self,idProf):
         professor=self.__profe_service.findById(idProf)
         return jsonify({
              "sucess":True,
              "message":"Executado com sucesso",
              "data":professor
         }),200
    
    def update(self,idProf):
         prof_atualizado=self.__profe_service.updateProf(idProf,request.json)
         if prof_atualizado:
              return jsonify({
                   "sucess":True,
                   "message":"Atualizao com sucesso",
                   "data":{
                        "professor":{
                             "idProfessor":int(idProf),
                             "nomeProfessor":request.json.get("professor",{}).get("nome")
                        }
                   }
              }),200
         else:
              return jsonify({
                   "sucess":False,
                   "error":{
                        "message":f"Não foi posssível atualizar o professor com ID {idProf}",
                        "code":404
                   },
                   "data":{}
              }),404
    
    def destroy(self,idProf):
         excluiu=self.__profe_service.deletaProf(idProf)
         if not excluiu:
              return jsonify({
                   "sucess":False,
                   "message":"Profesor não encontrado",
                   "error":{"message":f"Não existe professor com id {idProf}"}
              }),404
         return jsonify({
              "sucess":True,
              "message":"Excluído com sucesso"
         }),204

