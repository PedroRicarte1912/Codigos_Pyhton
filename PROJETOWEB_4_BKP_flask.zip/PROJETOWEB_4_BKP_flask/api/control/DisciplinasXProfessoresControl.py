from flask import request, jsonify
from api.service.DisciplinasXProfessoresService import DisciplinasXProfessoresService

class DisciplinasXProfessoresControl:
    def __Init__(self, dxp_service:DisciplinasXProfessoresService):
        print("⬆️  DisciplinasXProfessoresControl.constructor()")
        self.__dxp_service = dxp_service

    def store(self):
        print("🔵 DisciplinasXProfessoresControl.store()")
        dxp_body_request = request.json.get("disciplinas_x_professores")
        novo_id = self.__dxp_service.CriaDxP(dxp_body_request)
        obj_resposta={
            "sucess":True,
            "Message":"Cadastro realizado com sucesso",
            "data":{
                "disciplinas_x_professores":[
                    {
                        "Id_dxp":novo_id,
                        "CodigoDisciplinaNoCurso":dxp_body_request("CodigoDisciplinaNoCurso"),
                        "CodDisciplina":dxp_body_request("CodDisciplina"),
                        "CodProfessor":dxp_body_request("CodProfessor"),
                        "Curso":dxp_body_request("Curso"),
                        "CargaHoraria":dxp_body_request("CargaHoraria"),
                        "AnoLetivo":dxp_body_request("AnoLetivo")
                    }
                ]
            }
        }
        if novo_id:
            return jsonify(obj_resposta),200
        
    def index(self):
        print("🔵 DisciplinasXProfessoresControl.index()")
        array_dxp=self.__dxp_service.findAll()
        return jsonify({
            "sucess":True,
            "Message":"Busca realizada com sucesso",
            "data":{"DisciplinasXProfessores":array_dxp}
        }),200
    def show(self):
        id_dxp=request.view_args.get("id_dxp")
        dxp=self.__dxp_service.findById(id_dxp)
        obj_resposta={
            "sucess":True,
            "Message":"Executado com sucesso",
            "data":{"disciplinas_x_professores":dxp}
        }
        return jsonify(obj_resposta),200
    def update(self):
        print("🔵 DisciplinasXProfessoresControl.update()")
        id_dxp=request.view_args.get("id_dxp")
        json_dxp=request.json.get("disciplinas_x_professores")
        print(json_dxp)
        reposta=self.__dxp_service.atualiza(id_dxp,json_dxp)
        return jsonify({
            "success": True,
            "message": "disciplinas_x_professores atualizada com sucesso",
            "data": {
                "disciplinas_x_professores": {
                    "id_dxp": int(id_dxp),
                    "CodigoDisciplinaNoCurso": json_dxp.get("CodigoDisciplinaNoCurso"),
                    "CodDisciplina": json_dxp.get("CodDisciplina"),
                    "CodProfessor": json_dxp.get("CodProfessor"),
                    "Curso": json_dxp.get("Curso"),
                    "CargaHoraria": json_dxp.get("CargaHoraria"),
                    "AnoLetivo": json_dxp.get("AnoLetivo")
                }
            }
        }), 200
    