# -*- coding: utf-8 -*-
from functools import wraps
from flask import request
from api.utils.error_response import ErrorResponse

class ProfessoresMiddleware:
    def validate_create_body(self,f):
        @wraps(f)
        def decorated_function(*args,**kwargs):
            print("🔷 ProfessoresMiddleware.validate_create_body()")
            body=request.get_json()
            if not body or 'professor' not in body:
                raise ErrorResponse(400,"Erro na validação de dados",{"message":"O campo 'professor' é obrigatório!"})
            
            professor=body['professor']
            campos_obrig=["nome","email","id"]
            for campos in campos_obrig:
                if campos not in professor:
                    raise ErrorResponse(400,"Erro na validação de dados",{"message":f"O campo '{campos}' é obrigatório!"})
                
            if 'disciplina' not in professor or 'id_disciplina' not in professor['disciplina']:
                raise ErrorResponse(400,"Erro na validação de dados",{"message":"O campo 'disciplina.id_disciplina' é obrigatório!"})
            return f(*args,**kwargs)
        return decorated_function
    
    def validate_login_body(self, f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            print("🔷 ProfessoresMiddleware.validate_login_body()")
            body = request.get_json()

            if not body or 'professor' not in body:
                raise ErrorResponse(400, "Erro na validação de dados", {"message": "O campo 'professor' é obrigatório!"})

            professor = body['professor']

            campos_obrigatorios = ["email"]
            for campo in campos_obrigatorios:
                if campo not in professor:
                    raise ErrorResponse(400, "Erro na validação de dados", {"message": f"O campo '{campo}' é obrigatório!"})

            return f(*args, **kwargs)
        return decorated_function
    def validate_id_params(self,f):
        @wraps(f)
        def decorated_function(*args,**kwargs):
            print("🔷 ProfessoresMiddleware.validate_id_param()")
            if 'id' not in kwargs:
                raise ErrorResponse(400,"Erro na validação de daos",{"message":"O parâmetro 'id' é obrigatório!"})
            return f(*args,**kwargs)
        return decorated_function
    