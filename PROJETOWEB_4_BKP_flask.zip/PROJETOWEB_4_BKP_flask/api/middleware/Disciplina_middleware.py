from functools import wraps
from flask import request
from api.utils.error_response import ErrorResponse

class DisciplinaMiddleware:
    def validate_body(self,f):
        @wraps(f)
        def decorated_function(*args,**kwargs):
            print("🔷 DisciplinaMiddleware.validate_body()")
            body=request.get_json()

            if not body or 'disciplina' not in body:
                raise ErrorResponse(
                    400,"Erro na validação de dados",
                    {"message":"O campo 'disciplina' é obrigatório!"}
                )
            
            disciplina=body['disciplina']
            if 'id_disciplina' and 'nome_disciplina' not in disciplina:
                raise ErrorResponse(
                    400,"Erro na validação de dados",
                    {"message":"O campo 'id' e 'nome' são obrigatórios!"}
                )
            return f(*args,**kwargs)
        return decorated_function
    
    def validate_id_params(self,f):
        @wraps(f)
        def decorated_function(*args,**kwargs):
            print("🔷 DiciplinaMiddleware.validate_id_param()")
            if 'id_disciplina' not in kwargs:
                raise ErrorResponse(
                    400,"Erro na validação de dados",
                    {"message":"O parâmetro 'id' é obrigatório!"}
                )
            return f(*args,**kwargs)
        return decorated_function