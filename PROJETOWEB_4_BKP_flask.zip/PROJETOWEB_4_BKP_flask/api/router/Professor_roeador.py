from flask import Blueprint, request
from functools import wraps
from api.middleware.jwt_middleware import JwtMiddleware
from api.control.Professores_control import ProfessoresControl
from api.middleware.Professores_middleware import ProfessoresMiddleware

class ProfessorRoteador:
    def __init__(self,jwt_middleware:JwtMiddleware,prof_middleware:ProfessoresMiddleware,prof_control:ProfessoresControl):
        print("⬆️  ProfessorRoteador.__init__()")
        self.jwt_middleware=jwt_middleware
        self.prof_middleware=prof_middleware
        self.prof_control=prof_control

        self.blueprint=Blueprint('professor',__name__)

    def create_routes(self):
        @self.blueprint.route('/login',methods=['POST'])
        @self._flask_decorator(self.prof_middleware.validate_login_body)
        def login():
            print("ProfessorRoteador.login()")
            return self.prof_control.login()
        
        @self.blueprint.route('/',methods=['POST'])
        @self.jwt_middleware.validate_token
        @self._flask_decorator(self.prof_middleware.validate_create_body)
        def store():
            return self.prof_control.store()
        
        @self.blueprint.route('/<int:id>',methods=['PUT'])
        @self.jwt_middleware.validate_token
        @self._flask_decorator(self.prof_middleware.validate_id_params)
        @self._flask_decorator(self.prof_middleware.validate_create_body)
        def update(idProf):
            return self.prof_control.update(idProf)
        
        @self.blueprint.routes('/<int:id>',methods=['DELETE'])
        @self.jwt_middleware.validate_token
        @self._flask_decorator(self.prof_middleware.validate_id_params)
        def destroy(idProf):
            return self.prof_control.destroy(idProf)
        
        @self.blueprint.route('/',methods=['GET'])
        @self.jwt_middleware.validate_token
        def index():
            return self.prof_control.index()
        
        @self.blueprint.route('/<int:id>',methods=['GET'])
        @self.jwt_middleware.validate_token
        @self._flask_decorator(self.prof_middleware.validate_id_params)
        def show(idProf):
            return self.prof_control.show(idProf)
        return self.blueprint
    
    def _flask_decorator(self,middleware_func):
        def decorator(f):
            @wraps(f)
            def wrapper(*args,**kwargs):
                middleware_func(request)
                return f(*args,**kwargs)
            return wrapper
        return decorator