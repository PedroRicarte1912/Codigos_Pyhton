from flask import Blueprint, request
from api.middleware.jwt_middleware import JwtMiddleware
from api.middleware.Disciplina_middleware import DisciplinaMiddleware
from api.control.Disciplina_control import DisciplinaControl

class DisciplinaRoteador:
    def __init__(self,jwt_middleware: JwtMiddleware,disc_middleware: DisciplinaMiddleware,disc_control:DisciplinaControl):
         print("⬆️  DisciplinaRoteador.__init__()")
         self.__jwt_middleware=jwt_middleware
         self.__disc_middleware=disc_middleware
         self.__disc_control=disc_control

         self.__blueprint=Blueprint('disciplina',__name__)
    
    def create_routes(self):
        @self.__blueprint.route('/',methods=['POST'])
        @self.__jwt_middleware.validate_token
        @self.__disc_middleware.validate_body

        def store():
              return self.__disc_control.store()
         
        @self.__blueprint.route('/',methods=['GET'])
        @self.__jwt_middleware.validate_token
        def index():
              return self.__disc_control.index()
         
        @self.__blueprint.route('/<int:id_disciplina>',methods=['GET'])
        @self.__jwt_middleware.validate_token
        @self.__disc_middleware.validate_id_params
        def show(idDisc):
              return self.__disc_control.show(idDisc)
         
        @self.__blueprint.route('/<int:id_disciplina>',methods=['PUT'])
        @self.__jwt_middleware.validate_token
        @self.__disc_middleware.validate_id_params
        @self.__disc_middleware.validate_body
        def update(idDisc):
              return self.__disc_control.update()
         
        @self.__blueprint.route('/<int:id_disciplina>',methods=['DELETE'])
        @self.__jwt_middleware.validate_token
        @self.__disc_middleware.validate_id_params
        def destroy(idDisc):
            return self.__disc_control.destroy()
        return self.__blueprint