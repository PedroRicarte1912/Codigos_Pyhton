from api.utils.error_response import ErrorResponse
from api.model.Disciplinas import Disciplinas
from api.dao.Disciplinas_dao import DisciplinasDAO

class DisciplinaService:
    def __init__(self,disciplinas_dao_dependencia:DisciplinasDAO):
        print("⬆️  DisciplinaService.__init__()")
        self.__DisciplinaDAO = disciplinas_dao_dependencia

    #cria a disciplina
    def CriaDisc(self,disciplinaBodyRequest:dict)->int:
        print("🟣 DisciplinaService.CriaDisc()")

        disc = Disciplinas()
        disc.Iddisciplinas = disciplinaBodyRequest.get("id_disciplina")
        disc.Nomedisciplinas=disciplinaBodyRequest.get("nome_disciplina")
          # valida regra de negócio: cargo duplicado
        resultado = self.__disciplinaDAO.findByField("nome_disciplina", disc.Nomedisciplinas)
        if resultado and len(resultado) > 0:
            raise ErrorResponse(
                400,
                "Disciplina já existe",
                {"message": f"A disciplina {disc.Nomedisciplinas} já existe"}
            )

        return  self.__DisciplinaDAO.create(disc)
    
    #Acha todos os registros de Disciplinas
    def findAll(self)->list[dict]:
        print("🟣 DisciplinaService.findAll()")
        return self.__DisciplinaDAO.findAll()
    
    #Acha por id
    def findById(self,IdDisc:int)->dict|None:
        print("🟣 DisciplinaService.findById()")

        Disc = Disciplinas()
        Disc.Iddisciplinas = IdDisc  # passa pela validação de domínio

        return self.__DisciplinaDAO.findById(Disc.Iddisciplinas)
    
    #Atualiza a disciplina
    def atualiza(self, idDisc:int,jsonDisc:dict)->bool:
        print(jsonDisc)
        print("🟣 DisciplinaService.atualiza()")

        Disc = Disciplinas()
        Disc.Iddisciplinas = idDisc
        Disc.Nomedisciplinas = jsonDisc.get("nome_disciplina")

        return self.__DisciplinaDAO.update(Disc)
    
    #Deleta a disciplina
    def deleta(self,idDisc:int)->bool:
        print("🟣 DisciplinaService.deleta()")

        Disc = Disciplinas()
        Disc.Iddisciplinas = idDisc  # validação de regra de domínio

        return self.__DisciplinaDAO.delete(Disc)
    


    