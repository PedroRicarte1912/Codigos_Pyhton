from api.utils.error_response import ErrorResponse
from api.model.DisciplinasXProfessores import DisciplinasXProfessores
from api.dao.DisciplinasXProfessoresDAO import DisciplinasXProfessoresDAO

class DisciplinasXProfessoresService:
    def __init__(self, dxp_dao_dependencia: DisciplinasXProfessoresDAO):
        print("⬆️  DisciplinasXProfessoresService.__init__()")
        self.__dxpDAO = dxp_dao_dependencia

 # Cria uma nova relação entre disciplina e professor
    def CriaRelacao(self, dxpBodyRequest: dict) -> str:
        print("🟣 DisciplinasXProfessoresService.CriaRelacao()")

        dxp = DisciplinasXProfessores()
        dxp.CodigoDisciplinaNoCurso = dxpBodyRequest.get("codigodisciplinanocurso")
        dxp.CodDisciplina = dxpBodyRequest.get("coddisciplina")
        dxp.CodProfessor = dxpBodyRequest.get("codprofessor")
        dxp.Curso = dxpBodyRequest.get("curso")
        dxp.CargaHoraria = dxpBodyRequest.get("cargahoraria")
        dxp.AnoLetivo = dxpBodyRequest.get("anoletivo")

        # Verifica se já existe uma relação com o mesmo código
        resultado = self.__dxpDAO.findByField("codigodisciplinanocurso", dxp.CodigoDisciplinaNoCurso)
        if resultado and len(resultado) > 0:
            raise ErrorResponse(
                400,
                "Relação já existente",
                {"message": f"A relação com o código {dxp.CodigoDisciplinaNoCurso} já existe."}
            )

        return self.__dxpDAO.create(dxp)
    def findAll(self) -> list[dict]:
        print("🟣 DisciplinasXProfessoresService.findAll()")
        return self.__dxpDAO.findAll()
    
    def findById(self, IdDxP: str) -> dict | None:
        print("🟣 DisciplinasXProfessoresService.findById()")

        dxp = DisciplinasXProfessores()
        dxp.Iddxp = IdDxP  # validação de domínio

        return self.__dxpDAO.findById(dxp.Iddxp)
    
    def atualiza(self, codigo: str, jsonRelacao: dict) -> bool:
        print("🟣 DisciplinasXProfessoresService.atualiza()")
        print(jsonRelacao)

        dxp = DisciplinasXProfessores()
        dxp.CodigoDisciplinaNoCurso = codigo
        dxp.CodDisciplina = jsonRelacao.get("coddisciplina")
        dxp.CodProfessor = jsonRelacao.get("codprofessor")
        dxp.Curso = jsonRelacao.get("curso")
        dxp.CargaHoraria = jsonRelacao.get("cargahoraria")
        dxp.AnoLetivo = jsonRelacao.get("anoletivo")

        return self.__dxpDAO.update(dxp)