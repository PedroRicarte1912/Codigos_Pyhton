from api.utils.error_response import ErrorResponse
from api.http.meu_token_jwt import MeuTokenJWT
from api.dao.Professores_dao import ProfessoresDAO
from api.dao.Disciplinas_dao import DisciplinasDAO
from api.model.Professores import Professores
from api.model.Disciplinas import Disciplinas

class ProfessoresService:
    def __init__ (self,professores_dao_dependencia:ProfessoresDAO,disciplina_dao_dependencia:DisciplinasDAO):
        print("⬆️  ProfessoresService.__init__()")
        self.__Professoresdao=professores_dao_dependencia
        self.__Disciplinasdao=disciplina_dao_dependencia

    #cria professor
    def cria(self,jsonProf:dict)->Professores:
        print("🟣 ProfessoresService.cria()")

        Disc= Disciplinas()
        Disc.Iddisciplinas = jsonProf["nome_discipina"]["id_disciplina"]

        professor=Professores()
        professor.Nomeprofessores=jsonProf["nome"]
        professor.Idprofessores=jsonProf["id"]
        professor.Emailprofessores=jsonProf["email"]
        professor.disciplinas=Disc

         # regra de negócio: validar cargo
        cargoExiste =  self.__Disciplinasdao.findByField("id_disciplina", professor.disciplinas.Iddisciplinas)
        if not cargoExiste:
            raise ErrorResponse(
                400,
                "A disciplina informado não existe",
                {"message": f"A disciplina {professor.disciplinas.Iddisciplinas} não foi encontrado"}
            )

        # regra de negócio: validar email duplicado
        emailExiste =  self.__Professoresdao.findByField("email", professor.email)
        if emailExiste and len(emailExiste) > 0:
            raise ErrorResponse(
                400,
                "Professor já existe",
                {"message": f"O email {professor.email} já está cadastrado"}
            )
        return self.__Professoresdao.criar(professor)
    
    #login professor
    def login(self,jsonProf:dict)->dict:
        print("🟣 ProfessoresService.login()")
        print(jsonProf)

        professor = Professores()
        professor.Emailprofessores = jsonProf["email"]
      
        encontrado = self.__Professoresdao.login(professor)

        if not encontrado:
            raise ErrorResponse(
                401,
                "Usuário  inválidos",
                {"message": "Não foi possível realizar autenticação"}
            )

        jwt = MeuTokenJWT()
        user = {
            "professor": {
                "email": encontrado.email,
                "role": getattr(encontrado.cargo, "nomeCargo", None),
                "name": encontrado.Nomeprofessores,
                "idProfessor": encontrado.Idprofessores
            }
        }
        return {"user": user, "token": jwt.gerarToken(user["professor"])}
    
    #Acha todos os professores
    def findAll(self)->list[dict]:
         print("🟣 ProfessoresService.findAll()")
         return self.__Professoresdao.findAll()
    
    def findById(self,idProf:int)->dict:
        objProfe=Professores()
        objProfe.Idprofessores=idProf
        professor=self.__Professoresdao.findById(objProfe.Idprofessores)
        if not professor:
            raise ErrorResponse(
                404,
                "Professor não encontrado",
                {"message":f"Não existe professro com id {idProf}"}
            )
        return professor
    
    def updateProf(self,idProf:int,requestBody:dict)->bool:
        print("🟣 ProfessoresService.updateProf()")
        jsonProf=requestBody["professor"]
        objDisc=Disciplinas()
        objDisc.Iddisciplinas=jsonProf["disciplina"]["id_disciplina"]

        objProf=Professores()
        objProf.Idprofessores=idProf
        objProf.Nomeprofessores=jsonProf["nome"]
        objProf.Emailprofessores=jsonProf["email"]
        objProf.disciplinas=objDisc

        return self.__Professoresdao.atualiza(objProf)
    
    def deletaProf(self,idProf:int)->bool:
        print("🟣 ProfessoresService.deletaProf()")
        return self.__Professoresdao.deleta(idProf)