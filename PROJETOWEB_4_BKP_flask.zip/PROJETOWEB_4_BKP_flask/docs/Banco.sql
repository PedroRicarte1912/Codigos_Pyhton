
-- Remove o schema se existir
DROP SCHEMA IF EXISTS `PROJETOWEB_4_BKP`;

-- Cria o schema novamente
CREATE SCHEMA IF NOT EXISTS `PROJETOWEB_4_BKP` DEFAULT CHARACTER SET utf8;
USE `PROJEOTWEB_4_BKP`;

-- Remove tabelas caso existam (ordem importa por causa da FK)
DROP TABLE IF EXISTS `Disciplinas`;
DROP TABLE IF EXISTS `Professores`;

-- Criação da tabela Cargo
CREATE TABLE IF NOT EXISTS `Cargo` (
  `idCargo` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nomeCargo` VARCHAR(64) NOT NULL,
  PRIMARY KEY (`idCargo`),
  UNIQUE INDEX `idCargo_UNIQUE` (`idCargo` ASC),
  UNIQUE INDEX `nomeCargo_UNIQUE` (`nomeCargo` ASC)
) ENGINE = InnoDB;

-- Criação da tabela Funcionario
CREATE TABLE IF NOT EXISTS `Funcionario` (
  `idFuncionario` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `nomeFuncionario` VARCHAR(128) NULL,
  `email` VARCHAR(64) NULL,
  `senha` VARCHAR(64) NULL,
  `recebeValeTransporte` TINYINT(1) NULL,
  `Cargo_idCargo` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`idFuncionario`),
  UNIQUE INDEX `idFuncionario_UNIQUE` (`idFuncionario` ASC),
  UNIQUE INDEX `email_UNIQUE` (`email` ASC),
  INDEX `fk_Funcionario_Cargo_idx` (`Cargo_idCargo` ASC),
  CONSTRAINT `fk_Funcionario_Cargo`
    FOREIGN KEY (`Cargo_idCargo`)
    REFERENCES `Cargo` (`idCargo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION
) ENGINE = InnoDB;



