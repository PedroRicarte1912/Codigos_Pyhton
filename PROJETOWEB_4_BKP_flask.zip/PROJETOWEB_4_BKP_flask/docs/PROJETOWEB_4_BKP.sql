-- Remove o schema se existir
DROP SCHEMA IF EXISTS `PROJETOWEB_4_BKP`;

-- Cria o schema novamente
CREATE SCHEMA IF NOT EXISTS `PROJETOWEB_4_BKP` DEFAULT CHARACTER SET utf8;
USE `PROJEOTWEB_4_BKP`;

-- Remove tabelas caso existam (ordem importa por causa da FK)
DROP TABLE IF EXISTS `Disciplinas`;
DROP TABLE IF EXISTS `Professores`;

create table disciplinas(
id_disciplina int primary key,
nome_disciplina varchar(255))ENGINE = InnoDB;

create table professores(
id int primary key,
nome varchar(255),
email varchar(255),
id_disc int ,
foreign key(id_disc) references disciplinas(id_disciplina))ENGINE = InnoDB;

create table disciplinasXprofessores(
codigodisciplinanocurso varchar(10) primary key not null,
coddisciplina int null,
codprofessor int null,
curso int null,
cargahoraria int null,
anoletivo int null,
foreign key (coddisciplina) references disciplinas (id_disciplina),
foreign key (codprofessor) references professores (id))ENGINE = InnoDB;